const Colors = {
  Primary: 'royalblue',
  FirstList: '#00C9A7',
  SecondList: '#FF9671',
  Secondary: 'grey',
  Grey: 'lightgrey',
  Black: '#121212',
  White: '#fff'
}
export default Colors;