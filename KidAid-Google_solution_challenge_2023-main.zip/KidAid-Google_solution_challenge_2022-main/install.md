# How to install 
___
##### Clone speakid repository 
**Open terminal**

`git clone git@github.com:DSC-ENSB/Speakid.git` 
##### Open Speakid Directory
`cd Speakid`
##### Install npm dependencies
`npm install` 
##### Run 

`react-native run-android`

`react-native start`

> **NB :** react-native should be [configured](http://reactnative.dev/docs/environment-setup) in your machine 